var ads = [
  {
    id: 'classic',
    name: 'Classic Ad',
    price: 269.99
  },
  {
    id: 'standout',
    name: 'Standout Ad',
    price: 322.99
  },
  {
    id: 'premium',
    name: 'Premium Ad',
    price: 394.99
  }  
]

function calcTotal() {
    var selectInput = document.getElementById("customer");
    var classicAds = document.getElementsByName("classic");
    var standoutAds = document.getElementsByName("standout");
    var premiumAds = document.getElementsByName("premium");
    var calculate = document.getElementsByName("calculate");
    var newPurchase = document.getElementsByName("newPurchase");
    var total = Number(getClassic(selectInput.options[selectInput.selectedIndex].text, classicAds[0].value) +
      getStandout(selectInput.options[selectInput.selectedIndex].text, standoutAds[0].value) +
      getPremium(selectInput.options[selectInput.selectedIndex].text, premiumAds[0].value))
      .toFixed(2);

    document.getElementById("total").innerHTML = "$"+total;
    selectInput.disabled = true;
    classicAds[0].disabled = true;
    standoutAds[0].disabled = true;
    premiumAds[0].disabled = true;
    calculate[0].disabled = true;
    newPurchase[0].disabled = false;
}

function roundNumber(name) {
  var input = document.getElementsByName(name);
  input[0].value = Math.ceil(input[0].value);
}

function makeNewPurchase() {
    var selectInput = document.getElementById("customer");
    var classicAds = document.getElementsByName("classic");
    var standoutAds = document.getElementsByName("standout");
    var premiumAds = document.getElementsByName("premium");
    var calculate = document.getElementsByName("calculate");
    var newPurchase = document.getElementsByName("newPurchase");

    selectInput.disabled = false;
    selectInput.selectedIndex = 0;

    classicAds[0].disabled = false;
    classicAds[0].value = 0;

    standoutAds[0].disabled = false;
    standoutAds[0].value = 0;

    premiumAds[0].disabled = false;
    premiumAds[0].value = 0;

    calculate[0].disabled = false;
    newPurchase[0].disabled = true;

    document.getElementById("total").innerHTML = "";
}

function getClassic(customer, quantity) {
  var noOfAds = function (customer, quantity) {
    if (customer === 'UNILEVER') {
      return quantity - Math.floor(quantity/3);
    } else if (customer === 'FORD') {
      return quantity - Math.floor(quantity/5);
    }
    return quantity;
  }
  var ad = ads.find(function(ad) {
      return ad.id === 'classic';
  })
  return ad.price*noOfAds(customer, quantity);
}

function getStandout(customer, quantity) {
  var ad = ads.find(function(ad) {
      return ad.id === 'standout';
  })
  
  var price = ad.price;
  if (customer === 'APPLE') {
    price = 299.99;
  } else if (customer === 'FORD') {
    price = 309.99;
  }
  return price*quantity;
}

function getPremium(customer, quantity) {
  var ad = ads.find(function(ad) {
      return ad.id === 'premium';
  })
  
  var price = ad.price;
  if (customer === 'NIKE' && quantity >= 4) {
    price = 379.99;
  } else if (customer === 'FORD' && quantity >=3) {
    price = 389.99;
  }
  return price*quantity;
}